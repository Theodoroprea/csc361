Assignment 1 - CSC 361
Student: Theodor Oprea
Professor: Kui Wu

How to run the program:
- Using a terminal access the directory in which the SmartClient.py is located.
- To execute: python3 SmartClient.py <url>

Program has been tested and successfully run with:
- www.google.com
- www.gogle.com
- www.uvic.ca
- uvic.ca
- docs.engr.uvic.ca
- docs.engr.uvic.ca/docs/
- docs.engr.uvic.ca/docs
- facebook.com
- www.facebook.com
- http://facebook.com

- bccancer.bc.ca
- http://bcbcancer.bc.ca
- http://www.bcbcancer.bc.ca
